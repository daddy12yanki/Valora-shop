# Valora Shop
React + Tailwind demo shop (local admin using localStorage).

Commands:

```
npm install
npm start
```
