import React from 'react'
export default function ProductCard({ p, onEdit, onDelete }){
  return (
    <div className="bg-white rounded-md shadow overflow-hidden flex flex-col">
      <div className="h-44 bg-gray-100 flex items-center justify-center overflow-hidden">
        <img src={p.image} alt={p.title} className="w-full h-full object-cover" />
      </div>
      <div className="p-3 flex-1 flex flex-col">
        <h3 className="font-semibold text-lg">{p.title}</h3>
        <div className="text-sm text-gray-500">{p.category}</div>
        <p className="text-gray-600 mt-2 flex-1">{p.desc}</p>
        <div className="mt-3 flex items-center justify-between">
          <div className="text-xl font-bold">৳ {p.price}</div>
          <div className="flex gap-2">
            <button onClick={() => onEdit(p)} className="px-2 py-1 border rounded text-sm">Edit</button>
            <button onClick={() => onDelete(p.id)} className="px-2 py-1 border rounded text-sm text-red-600">Delete</button>
          </div>
        </div>
      </div>
    </div>
  )
}
