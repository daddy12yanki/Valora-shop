import React from 'react'
export default function Navbar({ onOpenAdmin }){
  return (
    <header className="bg-white shadow">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-2xl font-extrabold text-indigo-600">Valora</div>
          <span className="text-sm text-gray-500">Shop</span>
        </div>
        <div className="flex items-center gap-3">
          <input placeholder="Search products..." className="hidden sm:block border px-3 py-2 rounded text-sm w-64" />
          <button onClick={onOpenAdmin} className="bg-indigo-600 text-white px-3 py-2 rounded">Admin</button>
        </div>
      </div>
    </header>
  )
}
