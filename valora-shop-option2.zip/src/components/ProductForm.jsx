import React, { useEffect, useState } from 'react'
export default function ProductForm({ onAdd, onUpdate, editing, onClose }){
  const [title, setTitle] = useState('')
  const [price, setPrice] = useState('')
  const [desc, setDesc] = useState('')
  const [category, setCategory] = useState('general')
  const [imageData, setImageData] = useState('')

  useEffect(()=>{
    if(editing){
      setTitle(editing.title)
      setPrice(editing.price)
      setDesc(editing.desc)
      setCategory(editing.category)
      setImageData(editing.image)
    } else {
      setTitle(''); setPrice(''); setDesc(''); setCategory('general'); setImageData('')
    }
  },[editing])

  function handleImage(e){
    const f = e.target.files[0]
    if(!f) return
    const reader = new FileReader()
    reader.onload = ()=> setImageData(reader.result)
    reader.readAsDataURL(f)
  }
  function submit(e){
    e.preventDefault()
    if(!title||!price) return alert('Title and price required')
    const data = { title, price: Number(price), desc, category, image: imageData||'https://via.placeholder.com/600x400?text=No+Image' }
    if(editing) onUpdate(editing.id, data)
    else onAdd(data)
    setTitle(''); setPrice(''); setDesc(''); setImageData(''); setCategory('general')
  }
  return (
    <form onSubmit={submit} className="grid grid-cols-1 gap-3">
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" className="border px-3 py-2 rounded" />
      <input value={price} onChange={e=>setPrice(e.target.value)} placeholder="Price (BDT)" type="number" className="border px-3 py-2 rounded" />
      <select value={category} onChange={e=>setCategory(e.target.value)} className="border px-3 py-2 rounded">
        <option value="general">General</option>
        <option value="fashion">Fashion</option>
        <option value="accessories">Accessories</option>
        <option value="electronics">Electronics</option>
      </select>
      <textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Description" className="border px-3 py-2 rounded" rows={3} />
      <div>
        <input type="file" accept="image/*" onChange={handleImage} />
        {imageData && <div className="mt-2"><img src={imageData} alt="preview" className="w-40 h-24 object-cover border" /></div>}
      </div>
      <div className="flex gap-2">
        <button className="bg-indigo-600 text-white px-3 py-2 rounded" type="submit">{editing? 'Update' : 'Add Product'}</button>
        <button type="button" onClick={onClose} className="px-3 py-2 border rounded">Close</button>
      </div>
    </form>
  )
}
