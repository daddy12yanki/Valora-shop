import React from 'react'
import ProductForm from './ProductForm'

export default function AdminPanel({ onAdd, onUpdate, editing, onClose, onReset }){
  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="font-semibold mb-3">Admin Panel</h3>
      <ProductForm onAdd={onAdd} onUpdate={onUpdate} editing={editing} onClose={onClose} />
      <div className="mt-4 flex gap-2">
        <button onClick={onReset} className="px-3 py-2 border rounded text-sm">Reset Demo</button>
      </div>
    </div>
  )
}
