import React, { useEffect, useState } from 'react'
import Navbar from './components/Navbar'
import ProductCard from './components/ProductCard'
import AdminPanel from './components/AdminPanel'
import demoProducts from './data/demoProducts'

const STORAGE = 'valora_products_v1'

export default function App(){
  const [products, setProducts] = useState([])
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('all')
  const [adminOpen, setAdminOpen] = useState(false)
  const [editing, setEditing] = useState(null)

  useEffect(()=>{
    const raw = localStorage.getItem(STORAGE)
    if(raw) setProducts(JSON.parse(raw))
    else setProducts(demoProducts)
  },[])

  useEffect(()=>{
    localStorage.setItem(STORAGE, JSON.stringify(products))
  },[products])

  function addProduct(p){
    const id = 'p_' + Math.random().toString(36).slice(2,9)
    setProducts(prev => [{...p, id}, ...prev])
    setAdminOpen(false)
  }
  function updateProduct(id, data){
    setProducts(prev => prev.map(x=> x.id===id? {...x,...data} : x))
    setEditing(null)
    setAdminOpen(false)
  }
  function deleteProduct(id){
    if(!confirm('Are you sure?')) return
    setProducts(prev => prev.filter(x=> x.id!==id))
  }
  function resetDemo(){
    localStorage.removeItem(STORAGE)
    setProducts(demoProducts)
  }

  const visible = products.filter(p=> (filter==='all' || p.category===filter) && ( !query || p.title.toLowerCase().includes(query.toLowerCase()) || p.desc.toLowerCase().includes(query.toLowerCase())))

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar onOpenAdmin={()=> setAdminOpen(true)} />
      <main className="max-w-6xl mx-auto p-4 grid grid-cols-1 lg:grid-cols-4 gap-6">
        <aside className="lg:col-span-1 bg-white p-4 rounded shadow">
          <h4 className="font-semibold mb-2">Filters</h4>
          <input placeholder="Search..." value={query} onChange={e=>setQuery(e.target.value)} className="w-full border px-3 py-2 rounded" />
          <select className="mt-3 w-full border px-3 py-2 rounded" value={filter} onChange={e=>setFilter(e.target.value)}>
            <option value="all">All categories</option>
            <option value="fashion">Fashion</option>
            <option value="accessories">Accessories</option>
            <option value="electronics">Electronics</option>
            <option value="general">General</option>
          </select>
          <div className="mt-4 text-sm text-gray-600">Products: <strong>{products.length}</strong></div>
          <div className="mt-4"><button onClick={resetDemo} className="px-3 py-2 border rounded">Reset Demo</button></div>
        </aside>

        <section className="lg:col-span-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {visible.map(p=> (
              <ProductCard key={p.id} p={p} onEdit={(prod)=>{ setEditing(prod); setAdminOpen(true) }} onDelete={deleteProduct} />
            ))}
            {visible.length===0 && <div className="col-span-full text-center p-10 bg-white rounded">No products found.</div>}
          </div>
        </section>
      </main>

      {adminOpen && (
        <div className="fixed inset-0 bg-black/40 flex items-start justify-center p-6 z-50">
          <div className="w-full max-w-2xl bg-white rounded-md shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Admin — Add / Edit Product</h3>
              <div className="flex gap-2">
                <button onClick={()=>{ setAdminOpen(false); setEditing(null) }} className="px-3 py-1 border rounded">Close</button>
              </div>
            </div>
            <AdminPanel onAdd={addProduct} onUpdate={updateProduct} editing={editing} onClose={()=>{ setAdminOpen(false); setEditing(null) }} onReset={resetDemo} />
          </div>
        </div>
      )}

      <footer className="mt-10 py-6 text-center text-gray-500">© {new Date().getFullYear()} Valora</footer>
    </div>
  )
}
