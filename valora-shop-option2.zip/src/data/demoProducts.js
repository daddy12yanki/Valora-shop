const demoProducts = [
  { id: 'p1', title: 'Classic Leather Watch', price: 2499, category: 'accessories', desc: 'Stylish leather watch for everyday use.', image: 'https://via.placeholder.com/600x400?text=Watch' },
  { id: 'p2', title: 'Cotton T-Shirt', price: 799, category: 'fashion', desc: 'Comfortable cotton t-shirt available in multiple sizes.', image: 'https://via.placeholder.com/600x400?text=T-Shirt' },
  { id: 'p3', title: 'Phone Case', price: 350, category: 'electronics', desc: 'Durable protective phone case.', image: 'https://via.placeholder.com/600x400?text=Phone+Case' },
  { id: 'p4', title: 'Sunglasses', price: 1299, category: 'accessories', desc: 'UV-protected fashionable sunglasses.', image: 'https://via.placeholder.com/600x400?text=Sunglasses' },
  { id: 'p5', title: 'Sneakers', price: 2999, category: 'fashion', desc: 'Comfortable sneakers for daily wear.', image: 'https://via.placeholder.com/600x400?text=Sneakers' },
  { id: 'p6', title: 'Wireless Earbuds', price: 2199, category: 'electronics', desc: 'True wireless earbuds with long battery life.', image: 'https://via.placeholder.com/600x400?text=Earbuds' }
]
export default demoProducts
